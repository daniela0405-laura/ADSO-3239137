﻿# DOCUMENTACION
![](Aspose.Words.a739f744-f658-4a4d-aa32-f92c11b020d5.001.png)![](Aspose.Words.a739f744-f658-4a4d-aa32-f92c11b020d5.002.png)

![](Aspose.Words.a739f744-f658-4a4d-aa32-f92c11b020d5.003.png)


` `Entender lógica de negocio

El módulo de procesos permite gestionar la información relacionada con litigios, partes involucradas, representantes y poderes legales dentro del sistema Acme Litigios Demo.

El sistema permite navegar entre módulos administrativos y consultar información asociada a cada proceso.


Documentar [RF - RNF]

RF – Requisitos Funcionales

` `RF01

El sistema debe permitir visualizar los módulos del sistema.

` `RF02

El sistema debe permitir seleccionar módulos desde el menú lateral.

` `RF03

El sistema debe permitir consultar las partes asociadas a un proceso.

04

El sistema debe mostrar representantes y poderes registrados.



05

El sistema debe permitir cambiar entre vistas activas del menú.

` `RNF – Requisitos No Funcionales

01

La interfaz debe ser intuitiva y fácil de navegar.

02

El sistema debe responder correctamente al seleccionar módulos.

03

La interfaz debe mantener consistencia visual entre botones.

04

El sistema debe funcionar en navegador web.

\# Definición de HU

\## HU01 – Navegar entre módulos

Como administrador

quiero navegar entre los módulos del sistema

para consultar información relacionada con procesos jurídicos.

Se evidencia que

1

Se evidencia inconsistencia visual en los botones del menú lateral, ya que al seleccionar un módulo permanecen activos dos botones simultáneamente.

Tipo: bajo

2

Se evidencia cambio visual incorrecto en los botones al momento de presionar diferentes módulos del sistema.

Tipo: bajo

3

Se evidencia falta de control visual en el estado activo de navegación del menú lateral.

Tipo: medio

El sistema presenta fallos principalmente visuales en el menú de navegación lateral relacionados con el manejo de estados activos de botones. Aunque no afectan directamente el funcionamiento del sistema, sí impactan la experiencia de usuario y la claridad de navegación.

![Diagrama entidad-relación básico](Aspose.Words.a739f744-f658-4a4d-aa32-f92c11b020d5.004.png)![](Aspose.Words.a739f744-f658-4a4d-aa32-f92c11b020d5.005.png)
